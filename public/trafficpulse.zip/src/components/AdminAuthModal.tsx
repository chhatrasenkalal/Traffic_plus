import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Shield,
  Lock,
  Unlock,
  KeyRound,
  CheckCircle2,
  AlertTriangle,
  X,
  Zap,
  User,
  Fingerprint,
  Clock,
  Sliders,
  LogOut,
  ExternalLink,
  Copy,
  Check,
  Building2,
} from 'lucide-react';
import { useSimulation } from '../context/SimulationContext';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  navigate?: (route: string) => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  onClose,
  navigate,
}) => {
  const {
    isAdminAuthenticated,
    adminUser,
    loginAdmin,
    logoutAdmin,
  } = useSimulation();

  const [username, setUsername] = useState('admin');
  const [passcode, setPasscode] = useState('pulse2026');
  const [mfaCode, setMfaCode] = useState('982041');
  const [error, setError] = useState('');
  const [copiedToken, setCopiedToken] = useState(false);
  const [showPass, setShowPass] = useState(false);

  if (!isOpen) return null;

  const handleLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError('');

    const res = loginAdmin(username, passcode, mfaCode);
    if (!res.success) {
      setError(res.error || 'Invalid credentials. Try: admin / pulse2026');
    }
  };

  const handleQuickDemoLogin = () => {
    setUsername('admin');
    setPasscode('pulse2026');
    setMfaCode('982041');
    setError('');
    loginAdmin('admin', 'pulse2026', '982041');
  };

  const handleCopyToken = () => {
    if (adminUser?.token) {
      navigator.clipboard.writeText(adminUser.token);
      setCopiedToken(true);
      setTimeout(() => setCopiedToken(false), 2000);
    }
  };

  const handleGoToAdminPage = () => {
    onClose();
    if (navigate) {
      navigate('#/admin');
    } else {
      window.location.hash = '#/admin';
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-xl glass-panel-elevated rounded-2xl border border-[var(--border-light)] bg-gradient-to-b from-[#0E1424] to-[#07090F] shadow-2xl overflow-hidden my-8"
        >
          {/* Header Banner */}
          <div className="relative px-6 pt-6 pb-4 border-b border-[var(--border)] bg-gradient-to-r from-[#4F8CFF]/10 via-transparent to-[#2EE6A6]/10 flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#4F8CFF] to-[#2EE6A6] p-[1.5px] shadow-lg shadow-[#4F8CFF]/20 flex items-center justify-center">
                <div className="w-full h-full bg-[#080B14] rounded-[10px] flex items-center justify-center">
                  <Shield className="w-5 h-5 text-[#4F8CFF]" />
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] font-mono-data tracking-wider uppercase px-2 py-0.5 rounded-full bg-[#4F8CFF]/15 text-[#4F8CFF] border border-[#4F8CFF]/30 font-bold">
                    Municipal RBAC Gateway
                  </span>
                  <span className="text-[10px] font-mono-data uppercase px-2 py-0.5 rounded-full bg-[#FFB547]/15 text-[#FFB547] border border-[#FFB547]/30">
                    SIMULATED
                  </span>
                </div>
                <h2 className="font-heading text-lg font-bold text-white mt-1">
                  TrafficPulse Administrator Authentication
                </h2>
                <p className="text-xs text-[#8A94A9]">
                  Clearance Level 5 Citywide Control &amp; Overrides
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#8A94A9] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close authentication modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Authenticated State */}
            {isAdminAuthenticated && adminUser ? (
              <div className="space-y-5">
                <div className="p-4 rounded-xl bg-[#2EE6A6]/10 border border-[#2EE6A6]/30 flex items-start space-x-3">
                  <CheckCircle2 className="w-5 h-5 text-[#2EE6A6] flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-white">
                      Administrator Session Active
                    </h4>
                    <p className="text-xs text-[#8A94A9] mt-0.5">
                      You are authenticated as{' '}
                      <strong className="text-white">{adminUser.displayName}</strong>.
                      All administrative overrides and fail-safe controls across all web pages are unlocked.
                    </p>
                  </div>
                </div>

                {/* Session Details Card */}
                <div className="p-4 rounded-xl bg-[#07090F] border border-[var(--border)] space-y-3 text-xs">
                  <div className="flex items-center justify-between pb-2 border-b border-[var(--border)]">
                    <span className="text-[#8A94A9] font-medium">Clearance Level</span>
                    <span className="px-2 py-0.5 rounded bg-[#4F8CFF]/20 text-[#4F8CFF] font-mono-data font-bold border border-[#4F8CFF]/40">
                      LEVEL {adminUser.clearanceLevel} — ROOT TMC
                    </span>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b border-[var(--border)]">
                    <span className="text-[#8A94A9] font-medium">Session Token</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-mono-data text-white">{adminUser.token}</span>
                      <button
                        onClick={handleCopyToken}
                        className="p-1 rounded hover:bg-white/10 text-[#8A94A9] hover:text-white transition-colors"
                        title="Copy session token"
                      >
                        {copiedToken ? (
                          <Check className="w-3.5 h-3.5 text-[#2EE6A6]" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b border-[var(--border)]">
                    <span className="text-[#8A94A9] font-medium">Authenticated At</span>
                    <span className="font-mono-data text-white flex items-center space-x-1">
                      <Clock className="w-3 h-3 text-[#FFB547]" />
                      <span>{adminUser.loginTime}</span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#8A94A9] font-medium">Municipal Unit</span>
                    <span className="text-white flex items-center space-x-1">
                      <Building2 className="w-3 h-3 text-[#2EE6A6]" />
                      <span>City Department of Transportation (CDOT)</span>
                    </span>
                  </div>
                </div>

                {/* Privileges Granted */}
                <div className="p-3.5 rounded-xl bg-[#0E1424] border border-[var(--border)] space-y-2">
                  <span className="text-[11px] font-semibold text-[#8A94A9] uppercase tracking-wider block">
                    Active Administrative Privileges:
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-[#E8ECF5]">
                    <div className="flex items-center space-x-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#2EE6A6]" />
                      <span>17-Type Incident Injector</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#2EE6A6]" />
                      <span>Signal Timing Overrides</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#2EE6A6]" />
                      <span>Green Corridor Priority CAD</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#2EE6A6]" />
                      <span>Sensor Outage Simulation</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#2EE6A6]" />
                      <span>Citizen Report Approvals</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Zap className="w-3.5 h-3.5 text-[#2EE6A6]" />
                      <span>Digital Twin Reset</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <button
                    onClick={handleGoToAdminPage}
                    className="w-full sm:flex-1 py-2.5 px-4 rounded-xl text-xs font-semibold bg-[#4F8CFF] hover:bg-[#3D7AEE] text-white transition-colors cursor-pointer flex items-center justify-center space-x-2 shadow-lg shadow-[#4F8CFF]/20"
                  >
                    <Sliders className="w-4 h-4" />
                    <span>Open System Admin Console</span>
                    <ExternalLink className="w-3.5 h-3.5 ml-1" />
                  </button>

                  <button
                    onClick={() => {
                      logoutAdmin();
                    }}
                    className="w-full sm:w-auto py-2.5 px-4 rounded-xl text-xs font-semibold bg-[#FF5C6C]/15 hover:bg-[#FF5C6C] text-[#FF5C6C] hover:text-white border border-[#FF5C6C]/30 transition-colors cursor-pointer flex items-center justify-center space-x-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Lock / Sign Out</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Unauthenticated Login Form */
              <form onSubmit={handleLogin} className="space-y-4">
                {/* Notice */}
                <div className="p-3 rounded-xl bg-[#4F8CFF]/10 border border-[#4F8CFF]/25 text-xs text-[#E8ECF5] flex items-start space-x-2.5">
                  <Lock className="w-4 h-4 text-[#4F8CFF] flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white">Protected Administrator Console</span>
                    <p className="text-[#8A94A9] mt-0.5">
                      Enter municipal operator credentials to unlock fail-safe controls and telemetry overrides across each web page.
                    </p>
                  </div>
                </div>

                {error && (
                  <div className="p-3 rounded-xl bg-[#FF5C6C]/15 border border-[#FF5C6C]/40 text-xs text-[#FF5C6C] flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#8A94A9] uppercase mb-1">
                      Operator / Administrator ID
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-2.5 w-4 h-4 text-[#8A94A9]" />
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="admin"
                        className="w-full bg-[#07090F] border border-[var(--border)] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-[#8A94A9]/50 focus:border-[#4F8CFF] outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[11px] font-semibold text-[#8A94A9] uppercase">
                        Admin Passcode
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowPass(!showPass)}
                        className="text-[10px] text-[#4F8CFF] hover:underline"
                      >
                        {showPass ? 'Hide' : 'Show'}
                      </button>
                    </div>
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-2.5 w-4 h-4 text-[#8A94A9]" />
                      <input
                        type={showPass ? 'text' : 'password'}
                        value={passcode}
                        onChange={(e) => setPasscode(e.target.value)}
                        placeholder="pulse2026 or admin"
                        className="w-full bg-[#07090F] border border-[var(--border)] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-[#8A94A9]/50 focus:border-[#4F8CFF] outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[#8A94A9] uppercase mb-1 flex items-center justify-between">
                      <span>MFA / 2FA Security Token (Simulated)</span>
                      <span className="text-[10px] text-[#8A94A9] font-normal">Optional</span>
                    </label>
                    <div className="relative">
                      <Fingerprint className="absolute left-3 top-2.5 w-4 h-4 text-[#8A94A9]" />
                      <input
                        type="text"
                        value={mfaCode}
                        onChange={(e) => setMfaCode(e.target.value)}
                        placeholder="982041"
                        className="w-full bg-[#07090F] border border-[var(--border)] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-[#8A94A9]/50 focus:border-[#4F8CFF] outline-none font-mono-data"
                      />
                    </div>
                  </div>
                </div>

                {/* Quick Hint / Demo Credentials Box */}
                <div className="p-3 rounded-xl bg-[#FFB547]/10 border border-[#FFB547]/20 text-[11px] text-[#FFB547] space-y-1">
                  <div className="font-semibold flex items-center space-x-1.5">
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>Demo Credentials for Evaluation &amp; Exhibition</span>
                  </div>
                  <p className="text-[#8A94A9]">
                    Username: <code className="text-white font-mono-data">admin</code> • Passcode:{' '}
                    <code className="text-white font-mono-data">pulse2026</code> or{' '}
                    <code className="text-white font-mono-data">admin</code>
                  </p>
                </div>

                {/* Submit & Quick Demo Buttons */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <button
                    type="submit"
                    className="w-full sm:flex-1 py-2.5 px-4 rounded-xl text-xs font-semibold bg-[#4F8CFF] hover:bg-[#3D7AEE] text-white transition-colors cursor-pointer flex items-center justify-center space-x-2 shadow-lg shadow-[#4F8CFF]/20"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>Authenticate Console</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleQuickDemoLogin}
                    className="w-full sm:w-auto py-2.5 px-4 rounded-xl text-xs font-semibold bg-[#2EE6A6]/20 hover:bg-[#2EE6A6] text-[#2EE6A6] hover:text-[#07090F] border border-[#2EE6A6]/40 transition-colors cursor-pointer flex items-center justify-center space-x-2"
                  >
                    <Zap className="w-4 h-4" />
                    <span>⚡ Quick 1-Click Sign-In</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
