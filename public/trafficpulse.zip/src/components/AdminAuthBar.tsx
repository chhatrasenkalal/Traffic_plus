import React, { useState } from 'react';
import {
  Shield,
  Lock,
  Unlock,
  KeyRound,
  CheckCircle2,
  Sliders,
  LogOut,
  ChevronDown,
  ChevronUp,
  Zap,
} from 'lucide-react';
import { useSimulation } from '../context/SimulationContext';

interface AdminAuthBarProps {
  pageName?: string;
  navigate?: (route: string) => void;
  compact?: boolean;
}

export const AdminAuthBar: React.FC<AdminAuthBarProps> = ({
  pageName = 'This Page',
  navigate,
  compact = false,
}) => {
  const {
    isAdminAuthenticated,
    adminUser,
    openAdminAuthModal,
    logoutAdmin,
  } = useSimulation();

  const [minimized, setMinimized] = useState(false);

  if (compact) {
    return (
      <div className="flex items-center space-x-2 text-xs">
        {isAdminAuthenticated && adminUser ? (
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-[#2EE6A6]/10 border border-[#2EE6A6]/30 text-[#2EE6A6]">
            <span className="w-2 h-2 rounded-full bg-[#2EE6A6] animate-pulse" />
            <span className="font-semibold text-[11px]">Admin Lvl 5 Active</span>
            <button
              onClick={logoutAdmin}
              className="ml-1 text-[10px] text-[#8A94A9] hover:text-[#FF5C6C] underline cursor-pointer"
              title="Lock admin session"
            >
              Lock
            </button>
          </div>
        ) : (
          <button
            onClick={openAdminAuthModal}
            className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-md bg-[#FFB547]/10 hover:bg-[#FFB547]/20 border border-[#FFB547]/30 text-[#FFB547] text-[11px] font-semibold transition-colors cursor-pointer"
          >
            <Lock className="w-3 h-3" />
            <span>Admin Auth</span>
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="w-full transition-all duration-200">
      <div
        className={`rounded-xl border transition-all ${
          isAdminAuthenticated
            ? 'bg-gradient-to-r from-[#2EE6A6]/10 via-[#0E1424] to-[#4F8CFF]/10 border-[#2EE6A6]/30 shadow-lg shadow-[#2EE6A6]/5'
            : 'bg-gradient-to-r from-[#FFB547]/10 via-[#0B0F1C] to-[#07090F] border-[#FFB547]/25'
        } p-3 sm:px-4 text-xs`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          {/* Status Indicator */}
          <div className="flex items-center space-x-2.5">
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${
                isAdminAuthenticated
                  ? 'bg-[#2EE6A6]/20 text-[#2EE6A6]'
                  : 'bg-[#FFB547]/20 text-[#FFB547]'
              }`}
            >
              {isAdminAuthenticated ? (
                <Shield className="w-4 h-4" />
              ) : (
                <Lock className="w-4 h-4" />
              )}
            </div>

            <div className="leading-tight">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-white text-[12px]">
                  {isAdminAuthenticated
                    ? 'Administrator Clearance Active'
                    : 'Administrator Mode Locked'}
                </span>
                <span
                  className={`text-[10px] font-mono-data px-1.5 py-0.2 rounded font-semibold ${
                    isAdminAuthenticated
                      ? 'bg-[#2EE6A6]/20 text-[#2EE6A6]'
                      : 'bg-[#FFB547]/20 text-[#FFB547]'
                  }`}
                >
                  {isAdminAuthenticated
                    ? `LEVEL ${adminUser?.clearanceLevel || 5} ROOT`
                    : 'OPERATOR / PUBLIC VIEW'}
                </span>
              </div>
              <p className="text-[11px] text-[#8A94A9] mt-0.5">
                {isAdminAuthenticated
                  ? `Authenticated as ${adminUser?.username || 'admin'}. Full telemetry overrides and fail-safe controls enabled for ${pageName}.`
                  : `Viewing ${pageName} in read-only / operator mode. Authenticate as admin to unlock full control & override privileges.`}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-2 shrink-0 self-end sm:self-center">
            {isAdminAuthenticated ? (
              <>
                <button
                  onClick={() => {
                    if (navigate) navigate('#/admin');
                    else window.location.hash = '#/admin';
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-[#4F8CFF]/15 hover:bg-[#4F8CFF] text-[#4F8CFF] hover:text-white border border-[#4F8CFF]/30 text-[11px] font-semibold transition-colors cursor-pointer flex items-center space-x-1.5"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Admin Hub</span>
                </button>
                <button
                  onClick={openAdminAuthModal}
                  className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#E8ECF5] text-[11px] font-medium border border-[var(--border)] transition-colors cursor-pointer"
                  title="View active session token & permissions"
                >
                  Session
                </button>
                <button
                  onClick={logoutAdmin}
                  className="px-2.5 py-1.5 rounded-lg bg-[#FF5C6C]/15 hover:bg-[#FF5C6C] text-[#FF5C6C] hover:text-white border border-[#FF5C6C]/30 text-[11px] font-semibold transition-colors cursor-pointer flex items-center space-x-1"
                  title="Lock administrative console"
                >
                  <LogOut className="w-3 h-3" />
                  <span>Lock</span>
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={openAdminAuthModal}
                  className="px-3 py-1.5 rounded-lg bg-[#FFB547] hover:bg-[#FFA31A] text-[#07090F] font-bold text-[11px] shadow-sm transition-colors cursor-pointer flex items-center space-x-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Authenticate Admin</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
