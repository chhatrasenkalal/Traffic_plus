import React from 'react';
import {
  Activity,
  AlertCircle,
  Ambulance,
  Building2,
  CheckCircle2,
  Flame,
  Hospital,
  MapPin,
  Navigation,
  Radio,
  RotateCcw,
  Shield,
  ShieldAlert,
  Siren,
  Sparkles,
  Users,
  Zap,
} from 'lucide-react';
import { useSimulation } from '../context/SimulationContext';
import { EmergencyUnitState, EmergencyUnitType } from '../types';

export const EmergencyPage: React.FC = () => {
  const {
    emergencyUnits,
    hospitals,
    stations,
    activeIncidents,
    updateUnitState,
    dispatchUnit,
    activateGreenCorridor,
    deactivateGreenCorridor,
    greenCorridor,
  } = useSimulation();

  const getUnitIcon = (type: EmergencyUnitType) => {
    switch (type) {
      case 'AMBULANCE':
        return Ambulance;
      case 'POLICE':
        return Shield;
      case 'FIRE':
        return Flame;
    }
  };

  const getStateBadge = (state: EmergencyUnitState) => {
    switch (state) {
      case 'Available':
        return 'bg-[#2EE6A6]/20 text-[#2EE6A6] border-[#2EE6A6]/30';
      case 'Dispatched':
        return 'bg-[#4F8CFF]/20 text-[#4F8CFF] border-[#4F8CFF]/30';
      case 'En route':
        return 'bg-[#FFB547]/20 text-[#FFB547] border-[#FFB547]/30 animate-pulse';
      case 'On scene':
        return 'bg-[#FF5C6C]/20 text-[#FF5C6C] border-[#FF5C6C]/30';
      case 'Transporting/Resolving':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'At hospital':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      default:
        return 'bg-[#151C2E] text-[#8A94A9] border-[var(--border)]';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-[#E8ECF5]">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-[var(--border)] gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-mono-data text-[#2EE6A6] uppercase tracking-wider mb-1">
            <Siren className="w-3.5 h-3.5" />
            <span>Emergency Operations Center (SIMULATED)</span>
          </div>
          <h1 className="font-heading text-3xl font-bold text-white">
            CAD Fleet Dispatch & Hospital Routing
          </h1>
          <p className="text-sm text-[#8A94A9] mt-1">
            Autonomous multi-agency routing with traffic-calibrated hospital capacity matching and Green Corridor actuation.
          </p>
        </div>

        {/* Green Corridor Global Status Pill */}
        <div className="flex items-center space-x-3 bg-[#07090F] px-4 py-2 rounded-2xl border border-[var(--border)]">
          <Zap className={`w-4 h-4 ${greenCorridor ? 'text-[#2EE6A6] animate-pulse' : 'text-[#8A94A9]'}`} />
          <div>
            <div className="text-[10px] text-[#8A94A9]">Preemption Status</div>
            <div className={`font-mono-data font-bold text-xs ${greenCorridor ? 'text-[#2EE6A6]' : 'text-[#8A94A9]'}`}>
              {greenCorridor ? 'GREEN CORRIDOR ACTIVE' : 'Standard Dynamic Cycle'}
            </div>
          </div>
        </div>
      </div>

      {/* Honest Simulation Disclaimer Banner */}
      <div className="bg-[#4F8CFF]/10 border border-[#4F8CFF]/30 p-4 rounded-xl flex items-start space-x-3 text-xs text-[#4F8CFF]">
        <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
        <div>
          <strong className="font-semibold block mb-0.5">
            Strict Demonstration Disclosure
          </strong>
          <span>
            All emergency units, CAD states, hospital occupancy rates, and ambulance routes are 100% simulated digital twin entities. This application does NOT connect to real-world 112/911 PSAPs or public healthcare telemetry.
          </span>
        </div>
      </div>

      {/* Hospital Recommendation Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-heading font-bold text-lg text-white flex items-center space-x-2">
              <Hospital className="w-5 h-5 text-[#4F8CFF]" />
              <span>Simulated Metropolitan Hospital Telemetry</span>
            </h3>
            <p className="text-xs text-[#8A94A9]">
              Recommends the most appropriate hospital based on trauma capability and emergency load, not merely proximity.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {hospitals.map((hosp) => {
            const isRecommended = hosp.recommendationScore >= 90;
            const isHighLoad = hosp.emergencyLoad >= 85;

            return (
              <div
                key={hosp.id}
                className={`p-5 rounded-2xl border transition-all text-xs space-y-3 relative overflow-hidden ${
                  isRecommended
                    ? 'glass-panel-elevated border-[#2EE6A6]/40 shadow-lg shadow-[#2EE6A6]/10'
                    : 'glass-panel border-[var(--border)]'
                }`}
              >
                {isRecommended && (
                  <div className="absolute top-0 right-0 bg-[#2EE6A6] text-[#07090F] font-mono-data font-bold text-[9px] px-2.5 py-0.5 rounded-bl-lg uppercase">
                    AI Recommended Destination
                  </div>
                )}

                <div>
                  <h4 className="font-heading font-bold text-base text-white">
                    {hosp.name}
                  </h4>
                  <span className="text-[#8A94A9] text-[11px] block mt-0.5">
                    {hosp.specialty}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-[#07090F] p-2 rounded-xl border border-[var(--border)]">
                    <span className="text-[10px] text-[#8A94A9]">ER Load</span>
                    <div
                      className={`font-mono-data font-bold text-sm mt-0.5 ${
                        isHighLoad ? 'text-[#FF5C6C]' : 'text-[#2EE6A6]'
                      }`}
                    >
                      {hosp.emergencyLoad}%
                    </div>
                  </div>
                  <div className="bg-[#07090F] p-2 rounded-xl border border-[var(--border)]">
                    <span className="text-[10px] text-[#8A94A9]">ICU Beds</span>
                    <div className="font-mono-data font-bold text-sm text-white mt-0.5">
                      {hosp.icuBedsAvailable} / {hosp.totalBeds}
                    </div>
                  </div>
                  <div className="bg-[#07090F] p-2 rounded-xl border border-[var(--border)]">
                    <span className="text-[10px] text-[#8A94A9]">Traffic ETA</span>
                    <div className="font-mono-data font-bold text-sm text-[#4F8CFF] mt-0.5">
                      {hosp.trafficAdjustedEtaMinutes.toFixed(1)}m
                    </div>
                  </div>
                </div>

                {/* One line explanation requirement */}
                <div className="p-2.5 rounded-xl bg-[#07090F] border border-[var(--border)] text-[11px] leading-relaxed">
                  <span className="text-[#E8ECF5] font-medium">{hosp.recommendationReason}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Emergency Units Fleet Matrix */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-bold text-lg text-white flex items-center space-x-2">
            <Users className="w-5 h-5 text-[#2EE6A6]" />
            <span>Active Response Units Fleet ({emergencyUnits.length} Units)</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {emergencyUnits.map((unit) => {
            const Icon = getUnitIcon(unit.type);
            const isBusy = unit.state !== 'Available';

            return (
              <div
                key={unit.id}
                className="glass-panel p-5 rounded-2xl border border-[var(--border)] space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div
                        className="p-2 rounded-xl"
                        style={{ backgroundColor: `${unit.color}20`, color: unit.color }}
                      >
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-heading font-bold text-sm text-white">
                          {unit.callSign}
                        </h4>
                        <span className="text-[10px] font-mono-data text-[#8A94A9]">
                          {unit.type}
                        </span>
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono-data font-bold border ${getStateBadge(
                        unit.state
                      )}`}
                    >
                      {unit.state}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-[#8A94A9]">
                    <div className="flex justify-between">
                      <span>Current Junction:</span>
                      <strong className="text-white font-mono-data">{unit.currentJunctionId}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Home Station:</span>
                      <span className="text-white truncate max-w-[180px]">{unit.homeStation}</span>
                    </div>
                    {unit.assignedIncidentId && (
                      <div className="flex justify-between text-[#FFB547]">
                        <span>Assigned Incident:</span>
                        <strong className="font-mono-data">{unit.assignedIncidentId}</strong>
                      </div>
                    )}
                    {unit.assignedHospitalId && (
                      <div className="flex justify-between text-[#2EE6A6]">
                        <span>Target Facility:</span>
                        <strong className="font-mono-data">{unit.assignedHospitalId}</strong>
                      </div>
                    )}
                  </div>
                </div>

                {/* State Progression Controls */}
                <div className="pt-3 border-t border-[var(--border)] space-y-2">
                  <div className="flex flex-wrap gap-1.5 text-[10px]">
                    {unit.state === 'Dispatched' && (
                      <button
                        onClick={() => {
                          updateUnitState(unit.id, 'En route');
                          if (unit.assignedIncidentId && unit.targetJunctionId) {
                            activateGreenCorridor(unit.id, unit.assignedIncidentId, unit.currentJunctionId, unit.targetJunctionId);
                          }
                        }}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-[#FFB547] text-[#07090F] font-bold hover:brightness-110 cursor-pointer"
                      >
                        En Route (Start Siren)
                      </button>
                    )}
                    {unit.state === 'En route' && (
                      <button
                        onClick={() => updateUnitState(unit.id, 'On scene')}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-[#FF5C6C] text-white font-bold hover:brightness-110 cursor-pointer"
                      >
                        Mark On Scene
                      </button>
                    )}
                    {unit.state === 'On scene' && unit.type === 'AMBULANCE' && (
                      <button
                        onClick={() => updateUnitState(unit.id, 'Transporting/Resolving')}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-purple-500 text-white font-bold hover:brightness-110 cursor-pointer"
                      >
                        Transport to Hospital
                      </button>
                    )}
                    {unit.state === 'Transporting/Resolving' && (
                      <button
                        onClick={() => updateUnitState(unit.id, 'At hospital')}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-emerald-500 text-white font-bold hover:brightness-110 cursor-pointer"
                      >
                        Arrive At Hospital
                      </button>
                    )}
                    {(unit.state === 'On scene' || unit.state === 'At hospital') && (
                      <button
                        onClick={() => {
                          updateUnitState(unit.id, 'Available');
                          deactivateGreenCorridor('Unit Cleared Scene');
                        }}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-[#151C2E] border border-[var(--border)] text-[#2EE6A6] font-bold hover:bg-[#1e2638] cursor-pointer"
                      >
                        Clear & Return Available
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
